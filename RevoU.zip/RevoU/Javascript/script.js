let celciusInput = document.getElementById("celcius");
let fahrenheitInput = document.getElementById("fahrenheit");
let kelvinInput = document.getElementById("kelvin");
let reamurInput = document.getElementById("reamur");

let inputs = document.getElementsByClassName("input");

for(let i=0; i<inputs.length; i++) {
    let input = inputs[i];

    input.addEventListener("input", function(e) {
        let value = parseFloat(e.target.value);
        switch(e.target.name) {
            case "celcius":
                fahrenheitInput.value = (value * 1.8) + 32;
                kelvinInput.value = value + 273.15;
                reamurInput.value = value * 0.8;
                break;
            case "fahrenheit":
                celciusInput.value = (value - 32) / 1.8;
                kelvinInput.value = ((value - 32) / 1.8) + 273.15;
                reamurInput.value = ((value -32) / 1.8) * 0.8;
                break;
            case "kelvin":
                celciusInput.value = value - 273.15;
                fahrenheitInput.value = ((value - 273.15) * 1.8) + 32;
                reamurInput.value = ((value - 273.15) * 0.8);
                break;
            case "reamur":
                celciusInput.value = value * 1.25;
                fahrenheitInput.value = ((value  * 2.25) + 32);
                kelvinInput.value = ((value *1.25) + 273.15);
                break;
        }
    });
} 
